window.YTD.following.part0 = [
  {
    "following": {
      "accountId": "666",
      "userLink": "https://x.com/frida_x"
    }
  }
]