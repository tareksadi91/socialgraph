window.YTD.follower.part0 = [
  {
    "follower": {
      "accountId": "777",
      "userLink": "https://x.com/gus_x"
    }
  }
]