window.YTD.account.part0 = [
  {
    "account": {
      "accountId": "555",
      "username": "evan_x",
      "createdVia": "ios",
      "createdAt": "2015-06-15T00:00:00.000Z",
      "accountDisplayName": "Evan"
    }
  }
]