window.YTD.account.part0 = [
  {
    "account": {
      "accountId": "111",
      "username": "alice_x",
      "createdVia": "web",
      "createdAt": "2010-01-01T00:00:00.000Z",
      "accountDisplayName": "Alice"
    }
  }
]