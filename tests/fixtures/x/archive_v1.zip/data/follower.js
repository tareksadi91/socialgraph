window.YTD.follower.part0 = [
  {
    "follower": {
      "accountId": "444",
      "userLink": "https://twitter.com/dan_x"
    }
  }
]