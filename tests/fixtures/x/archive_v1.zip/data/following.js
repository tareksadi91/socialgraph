window.YTD.following.part0 = [
  {
    "following": {
      "accountId": "222",
      "userLink": "https://twitter.com/bob_x"
    }
  },
  {
    "following": {
      "accountId": "333",
      "userLink": "https://twitter.com/carol_x"
    }
  }
]